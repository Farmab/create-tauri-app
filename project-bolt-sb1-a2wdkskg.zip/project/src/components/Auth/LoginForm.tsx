import React, { useState } from 'react';
import { Lock, User, IceCream, Building } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useTranslation } from '../../hooks/useTranslation';

export function LoginForm() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login, isLoading } = useAuth();
  const { t } = useTranslation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username || !password) {
      setError(t('fillAllFields'));
      return;
    }

    const success = await login(username, password);
    if (!success) {
      setError(t('invalidCredentials'));
    }
  };

  const demoAccounts = [
    { username: 'admin_main', password: 'password', branch: 'Main Branch - Downtown', role: 'Admin' },
    { username: 'cashier_main', password: 'password', branch: 'Main Branch - Downtown', role: 'Cashier' },
    { username: 'admin_north', password: 'password', branch: 'North Branch - Mall', role: 'Admin' },
    { username: 'cashier_north', password: 'password', branch: 'North Branch - Mall', role: 'Cashier' },
    { username: 'admin_south', password: 'password', branch: 'South Branch - Plaza', role: 'Admin' },
    { username: 'cashier_south', password: 'password', branch: 'South Branch - Plaza', role: 'Cashier' },
    { username: 'owner', password: 'password', branch: 'All Branches', role: 'Owner' }
  ];

  const fillCredentials = (username: string, password: string) => {
    setUsername(username);
    setPassword(password);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-500 via-purple-600 to-indigo-700 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl p-8 w-full max-w-4xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Login Form */}
          <div>
            <div className="text-center mb-8">
              <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 rounded-full inline-block mb-4">
                <IceCream className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                Ice Cream POS
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                {t('signIn')}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('username')}
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-colors"
                    placeholder={t('username')}
                    disabled={isLoading}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('password')}
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-colors"
                    placeholder={t('password')}
                    disabled={isLoading}
                  />
                </div>
              </div>

              {error && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
                  <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-3 rounded-lg font-medium hover:from-pink-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {isLoading ? t('signingIn') : t('signIn')}
              </button>
            </form>
          </div>

          {/* Demo Accounts */}
          <div>
            <div className="text-center mb-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                Demo Accounts
              </h2>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Click any account below to auto-fill credentials
              </p>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {demoAccounts.map((account, index) => (
                <button
                  key={index}
                  onClick={() => fillCredentials(account.username, account.password)}
                  className="w-full p-4 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-left border border-gray-200 dark:border-gray-700"
                >
                  <div className="flex items-center space-x-3">
                    <div className="bg-gradient-to-r from-blue-500 to-cyan-600 p-2 rounded-full">
                      <Building className="h-4 w-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900 dark:text-white">
                          {account.username}
                        </span>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          account.role === 'Owner' 
                            ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400'
                            : account.role === 'Admin'
                            ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
                            : 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                        }`}>
                          {account.role}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {account.branch}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                        Password: {account.password}
                      </p>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <h3 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
                🏢 Branch-Based Authentication
              </h3>
              <ul className="text-xs text-blue-800 dark:text-blue-200 space-y-1">
                <li>• Each user belongs to a specific branch</li>
                <li>• Login automatically switches to user's branch</li>
                <li>• Data is isolated per branch</li>
                <li>• Owners can access all branches</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}