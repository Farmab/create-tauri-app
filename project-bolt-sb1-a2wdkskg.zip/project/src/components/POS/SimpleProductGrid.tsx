import React from 'react';
import { Package } from 'lucide-react';
import { Product, Category } from '../../types';
import { useApp } from '../../context/AppContext';
import { CategoryFilter } from './CategoryFilter';

interface SimpleProductGridProps {
  products: Product[];
  categories: Category[];
  selectedCategory: string;
  selectedQuantity: number | null;
  onProductSelect: (product: Product) => void;
  onQuantitySelect: (quantity: number) => void;
  onCategorySelect: (categoryId: string) => void;
}

export function SimpleProductGrid({ 
  products, 
  categories,
  selectedCategory,
  selectedQuantity, 
  onProductSelect, 
  onQuantitySelect,
  onCategorySelect
}: SimpleProductGridProps) {
  const { state } = useApp();
  const colorPalette = state.settings.colorPalette;
  const quantities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  // Filter products by category
  const filteredProducts = products.filter(product => 
    selectedCategory === 'all' || product.categoryId === selectedCategory
  );

  return (
    <div className="space-y-6">
      {/* Category Filter */}
      <CategoryFilter
        categories={categories}
        selectedCategory={selectedCategory}
        onCategorySelect={onCategorySelect}
      />

      {/* Quantity Buttons Row */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 text-center">
          Select Quantity
        </h3>
        <div className="grid grid-cols-10 gap-2">
          {quantities.map((qty) => (
            <button
              key={qty}
              onClick={() => onQuantitySelect(qty)}
              className={`aspect-square text-lg font-bold rounded-lg transition-all shadow-md hover:shadow-lg transform hover:scale-105 ${
                selectedQuantity === qty
                  ? `${colorPalette.gradient} text-white shadow-lg`
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              {qty}
            </button>
          ))}
        </div>
        {selectedQuantity && (
          <div className="mt-3 text-center">
            <p className={`font-medium bg-gradient-to-r ${colorPalette.primary} bg-clip-text text-transparent`}>
              Selected: {selectedQuantity} - Click any item below to add this quantity
            </p>
          </div>
        )}
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {filteredProducts.map((product) => (
          <button
            key={product.id}
            onClick={() => onProductSelect(product)}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 transition-all duration-200 hover:shadow-lg hover:border-opacity-50 hover:scale-105 cursor-pointer group"
            style={{
              '--hover-border': colorPalette.primary.includes('blue') ? '#3B82F6' : 
                               colorPalette.primary.includes('purple') ? '#8B5CF6' :
                               colorPalette.primary.includes('green') ? '#10B981' :
                               colorPalette.primary.includes('orange') ? '#F97316' :
                               colorPalette.primary.includes('teal') ? '#14B8A6' : '#6366F1'
            } as React.CSSProperties}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = (e.currentTarget.style as any)['--hover-border'];
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '';
            }}
          >
            <div className="aspect-square rounded-lg overflow-hidden mb-3 bg-gray-100 dark:bg-gray-700">
              {product.image ? (
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="h-8 w-8 text-gray-400" />
                </div>
              )}
            </div>

            <div className="text-left">
              <h3 className="font-medium text-gray-900 dark:text-white text-sm mb-1 truncate">
                {product.name}
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-2 truncate">
                {product.category}
              </p>
              <div className="flex items-center justify-center">
                <span className={`text-lg font-bold bg-gradient-to-r ${colorPalette.primary} bg-clip-text text-transparent`}>
                  {state.settings.currency === 'IQD' ? `${(product.basePrice * 1500).toLocaleString()} د.ع` : `$${product.basePrice.toFixed(2)}`}
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">
            {selectedCategory === 'all' ? 'No products available' : 'No products in this category'}
          </p>
        </div>
      )}
    </div>
  );
}