import React, { useState } from 'react';
import { SimpleProductGrid } from '../components/POS/SimpleProductGrid';
import { SimpleOrderSummary } from '../components/POS/SimpleOrderSummary';
import { OrderHistory } from '../components/POS/OrderHistory';
import { OrderDetailModal } from '../components/POS/OrderDetailModal';
import { useProducts } from '../hooks/useProducts';
import { useCategories } from '../hooks/useCategories';
import { useOrders } from '../hooks/useOrders';
import { useApp } from '../context/AppContext';
import { useTranslation } from '../hooks/useTranslation';
import { useAutoBackup } from '../hooks/useAutoBackup';
import { generate80mmReceipt, printReceipt } from '../utils/printUtils';
import { Product, OrderItem, Order } from '../types';

export function MenuView() {
  const { products } = useProducts();
  const { categories } = useCategories();
  const { orders, createOrder } = useOrders();
  const { state } = useApp();
  const { t } = useTranslation();
  const { manualBackup } = useAutoBackup();
  const isRTL = state.settings.language === 'ar';
  
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedQuantity, setSelectedQuantity] = useState<number | null>(1);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
  };

  const handleQuantitySelect = (quantity: number) => {
    setSelectedQuantity(quantity);
  };

  const handleProductSelect = (product: Product) => {
    const quantityToAdd = selectedQuantity || 1;

    const existingItem = orderItems.find(item => item.productId === product.id);
    
    if (existingItem) {
      setOrderItems(items =>
        items.map(item =>
          item.id === existingItem.id
            ? {
                ...item,
                quantity: item.quantity + quantityToAdd,
                total: (item.quantity + quantityToAdd) * product.basePrice
              }
            : item
        )
      );
    } else {
      const orderItem: OrderItem = {
        id: Date.now().toString(),
        productId: product.id,
        productName: product.name,
        basePrice: product.basePrice,
        quantity: quantityToAdd,
        variants: [],
        total: quantityToAdd * product.basePrice
      };
      setOrderItems([...orderItems, orderItem]);
    }

    setSelectedQuantity(1);
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    setOrderItems(items =>
      items.map(item => {
        if (item.id === itemId) {
          return {
            ...item,
            quantity,
            total: quantity * item.basePrice
          };
        }
        return item;
      })
    );
  };

  const removeItem = (itemId: string) => {
    setOrderItems(items => items.filter(item => item.id !== itemId));
  };

  const clearOrder = () => {
    setOrderItems([]);
    setSelectedQuantity(1);
  };

  const handlePrint = async () => {
    if (orderItems.length === 0) return;

    try {
      // Create and complete order automatically
      const order = await createOrder(orderItems);
      if (order) {
        const printContent = generate80mmReceipt(order, state.settings, isRTL, t);
        printReceipt(printContent);
        clearOrder();
      }
    } catch (error) {
      console.error('Failed to create order:', error);
    }
  };

  const handlePrintOrder = (order: Order) => {
    const printContent = generate80mmReceipt(order, state.settings, isRTL, t);
    printReceipt(printContent);
  };

  const subtotal = orderItems.reduce((sum, item) => sum + item.total, 0);
  const tax = 0; // Tax removed
  const total = subtotal; // No tax added

  return (
    <div className={`flex h-full gap-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
      <div className="flex-1 flex flex-col gap-6">
        <div className="flex-1">
          <SimpleProductGrid
            products={products}
            categories={categories}
            selectedCategory={selectedCategory}
            selectedQuantity={selectedQuantity}
            onProductSelect={handleProductSelect}
            onQuantitySelect={handleQuantitySelect}
            onCategorySelect={handleCategorySelect}
          />
        </div>
        
        <div className="h-80">
          <OrderHistory
            orders={orders}
            onViewOrder={setSelectedOrder}
            onPrintOrder={handlePrintOrder}
          />
        </div>
      </div>

      <div className="w-96">
        <SimpleOrderSummary
          items={orderItems}
          subtotal={subtotal}
          tax={tax}
          total={total}
          onUpdateQuantity={updateQuantity}
          onRemoveItem={removeItem}
          onPrint={handlePrint}
          onClearOrder={clearOrder}
        />
      </div>

      <OrderDetailModal
        order={selectedOrder}
        onClose={() => setSelectedOrder(null)}
        onPrint={handlePrintOrder}
      />
    </div>
  );
}