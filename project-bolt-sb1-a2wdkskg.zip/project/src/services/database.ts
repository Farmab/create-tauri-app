import initSqlJs, { Database } from 'sql.js';

class DatabaseService {
  private db: Database | null = null;
  private isInitialized = false;

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      const SQL = await initSqlJs({
        locateFile: (file) => `https://sql.js.org/dist/${file}`
      });

      // Try to load existing database from localStorage
      const savedDb = localStorage.getItem('pos_database');
      if (savedDb) {
        const uint8Array = new Uint8Array(JSON.parse(savedDb));
        this.db = new SQL.Database(uint8Array);
      } else {
        this.db = new SQL.Database();
        await this.createTables();
        await this.seedInitialData();
      }

      this.isInitialized = true;
      console.log('✅ Database initialized successfully');
    } catch (error) {
      console.error('❌ Failed to initialize database:', error);
      throw error;
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const tables = [
      // Branches table
      `CREATE TABLE IF NOT EXISTS branches (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        address TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        isActive INTEGER DEFAULT 1,
        managerId TEXT,
        settings TEXT,
        createdAt TEXT NOT NULL
      )`,

      // Users table
      `CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        email TEXT NOT NULL,
        role TEXT NOT NULL,
        firstName TEXT NOT NULL,
        lastName TEXT NOT NULL,
        isActive INTEGER DEFAULT 1,
        password TEXT NOT NULL,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // Categories table
      `CREATE TABLE IF NOT EXISTS categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        isActive INTEGER DEFAULT 1,
        sortOrder INTEGER DEFAULT 0,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // Products table
      `CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        categoryId TEXT NOT NULL,
        category TEXT NOT NULL,
        basePrice REAL NOT NULL,
        image TEXT,
        isActive INTEGER DEFAULT 1,
        stock INTEGER DEFAULT 0,
        minStock INTEGER DEFAULT 5,
        variants TEXT,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (categoryId) REFERENCES categories (id),
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // Orders table
      `CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY,
        orderNumber TEXT NOT NULL,
        items TEXT NOT NULL,
        subtotal REAL NOT NULL,
        tax REAL DEFAULT 0,
        discount REAL DEFAULT 0,
        total REAL NOT NULL,
        paymentMethod TEXT NOT NULL,
        status TEXT NOT NULL,
        customerName TEXT,
        customerNote TEXT,
        cashierId TEXT NOT NULL,
        cashierName TEXT NOT NULL,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        completedAt TEXT NOT NULL,
        FOREIGN KEY (cashierId) REFERENCES users (id),
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // Customers table
      `CREATE TABLE IF NOT EXISTS customers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        loyaltyPoints INTEGER DEFAULT 0,
        totalSpent REAL DEFAULT 0,
        lastVisit TEXT NOT NULL,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // App settings table
      `CREATE TABLE IF NOT EXISTS app_settings (
        id TEXT PRIMARY KEY,
        businessName TEXT NOT NULL,
        logo TEXT,
        taxRate REAL DEFAULT 0,
        currency TEXT DEFAULT 'IQD',
        theme TEXT DEFAULT 'light',
        language TEXT DEFAULT 'ku',
        receiptFooter TEXT,
        colorPalette TEXT,
        currentBranchId TEXT NOT NULL
      )`
    ];

    for (const table of tables) {
      this.db.run(table);
    }
  }

  private async seedInitialData(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    // Create multiple branches
    const branches = [
      {
        id: 'branch-1',
        name: 'Main Branch - Downtown',
        address: '123 Main Street, Downtown, City',
        phone: '+964 750 123 4567',
        email: 'main@icecream.com'
      },
      {
        id: 'branch-2',
        name: 'North Branch - Mall',
        address: '456 Mall Avenue, North District, City',
        phone: '+964 750 234 5678',
        email: 'north@icecream.com'
      },
      {
        id: 'branch-3',
        name: 'South Branch - Plaza',
        address: '789 Plaza Street, South District, City',
        phone: '+964 750 345 6789',
        email: 'south@icecream.com'
      }
    ];

    const defaultBranchSettings = {
      businessName: 'Ice Cream Paradise',
      taxRate: 0,
      currency: 'IQD',
      theme: 'light',
      language: 'ku',
      receiptFooter: 'Thank you for your visit!',
      colorPalette: {
        id: 'blue',
        name: 'Ocean Blue',
        primary: 'from-blue-500 to-cyan-600',
        secondary: 'from-blue-600 to-cyan-700',
        gradient: 'bg-gradient-to-r from-blue-500 to-cyan-600'
      }
    };

    // Insert branches
    for (const branch of branches) {
      this.db.run(`
        INSERT INTO branches (id, name, address, phone, email, isActive, settings, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        branch.id,
        branch.name,
        branch.address,
        branch.phone,
        branch.email,
        1,
        JSON.stringify(defaultBranchSettings),
        new Date().toISOString()
      ]);
    }

    // Create users for different branches
    const users = [
      // Main Branch Users
      {
        id: 'user-1',
        username: 'admin_main',
        email: 'admin.main@icecream.com',
        role: 'admin',
        firstName: 'Ahmad',
        lastName: 'Hassan',
        password: 'password',
        branchId: 'branch-1'
      },
      {
        id: 'user-2',
        username: 'cashier_main',
        email: 'cashier.main@icecream.com',
        role: 'cashier',
        firstName: 'Fatima',
        lastName: 'Ali',
        password: 'password',
        branchId: 'branch-1'
      },
      // North Branch Users
      {
        id: 'user-3',
        username: 'admin_north',
        email: 'admin.north@icecream.com',
        role: 'admin',
        firstName: 'Omar',
        lastName: 'Mohammed',
        password: 'password',
        branchId: 'branch-2'
      },
      {
        id: 'user-4',
        username: 'cashier_north',
        email: 'cashier.north@icecream.com',
        role: 'cashier',
        firstName: 'Zara',
        lastName: 'Ahmed',
        password: 'password',
        branchId: 'branch-2'
      },
      // South Branch Users
      {
        id: 'user-5',
        username: 'admin_south',
        email: 'admin.south@icecream.com',
        role: 'admin',
        firstName: 'Kareem',
        lastName: 'Salim',
        password: 'password',
        branchId: 'branch-3'
      },
      {
        id: 'user-6',
        username: 'cashier_south',
        email: 'cashier.south@icecream.com',
        role: 'cashier',
        firstName: 'Layla',
        lastName: 'Rashid',
        password: 'password',
        branchId: 'branch-3'
      },
      // Owner (can access all branches)
      {
        id: 'user-owner',
        username: 'owner',
        email: 'owner@icecream.com',
        role: 'owner',
        firstName: 'Salam',
        lastName: 'Kurdistan',
        password: 'password',
        branchId: 'branch-1' // Default branch
      }
    ];

    for (const user of users) {
      this.db.run(`
        INSERT INTO users (id, username, email, role, firstName, lastName, password, branchId, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        user.id,
        user.username,
        user.email,
        user.role,
        user.firstName,
        user.lastName,
        user.password,
        user.branchId,
        new Date().toISOString()
      ]);
    }

    // Create categories for each branch
    const categoryTemplates = [
      { name: 'Soft Ice Cream', description: 'Creamy soft serve ice cream varieties', sortOrder: 1 },
      { name: 'Natural Ice Cream', description: 'All-natural ice cream made with organic ingredients', sortOrder: 2 },
      { name: 'Italian Ice Cream', description: 'Authentic Italian gelato and ice cream', sortOrder: 3 },
      { name: 'Juices', description: 'Fresh fruit juices and smoothies', sortOrder: 4 },
      { name: 'Toppings', description: 'Delicious toppings and add-ons', sortOrder: 5 }
    ];

    let categoryId = 1;
    for (const branch of branches) {
      for (const template of categoryTemplates) {
        this.db.run(`
          INSERT INTO categories (id, name, description, isActive, sortOrder, branchId, createdAt)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          `cat-${categoryId}`,
          template.name,
          template.description,
          1,
          template.sortOrder,
          branch.id,
          new Date().toISOString()
        ]);
        categoryId++;
      }
    }

    // Create products for each branch
    const productTemplates = [
      {
        name: 'Vanilla Soft Serve',
        description: 'Classic vanilla soft serve ice cream',
        categoryName: 'Soft Ice Cream',
        basePrice: 4.99,
        image: 'https://images.pexels.com/photos/1362534/pexels-photo-1362534.jpeg?auto=compress&cs=tinysrgb&w=400',
        stock: 50,
        minStock: 10
      },
      {
        name: 'Chocolate Soft Serve',
        description: 'Rich chocolate soft serve ice cream',
        categoryName: 'Soft Ice Cream',
        basePrice: 5.49,
        image: 'https://images.pexels.com/photos/2373520/pexels-photo-2373520.jpeg?auto=compress&cs=tinysrgb&w=400',
        stock: 45,
        minStock: 10
      }
    ];

    const variants = JSON.stringify([
      { id: 'v1', name: 'Cup', price: 0, type: 'container' },
      { id: 'v2', name: 'Cone', price: 0.5, type: 'container' },
      { id: 'v3', name: 'Small', price: 0, type: 'size' },
      { id: 'v4', name: 'Medium', price: 1.5, type: 'size' },
      { id: 'v5', name: 'Large', price: 3.0, type: 'size' }
    ]);

    let productId = 1;
    for (const branch of branches) {
      for (const template of productTemplates) {
        // Find the category ID for this branch
        const categoryStmt = this.db.prepare('SELECT id FROM categories WHERE name = ? AND branchId = ?');
        categoryStmt.bind([template.categoryName, branch.id]);
        let categoryId = '';
        if (categoryStmt.step()) {
          categoryId = categoryStmt.getAsObject().id as string;
        }
        categoryStmt.free();

        this.db.run(`
          INSERT INTO products (id, name, description, categoryId, category, basePrice, image, isActive, stock, minStock, variants, branchId, createdAt)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          `prod-${productId}`,
          template.name,
          template.description,
          categoryId,
          template.categoryName,
          template.basePrice,
          template.image,
          1,
          template.stock,
          template.minStock,
          variants,
          branch.id,
          new Date().toISOString()
        ]);
        productId++;
      }
    }

    // Create default app settings
    this.db.run(`
      INSERT INTO app_settings (id, businessName, taxRate, currency, theme, language, receiptFooter, colorPalette, currentBranchId)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      'settings-1',
      'Ice Cream Paradise',
      0,
      'IQD',
      'light',
      'ku',
      'Thank you for your visit!',
      JSON.stringify(defaultBranchSettings.colorPalette),
      'branch-1'
    ]);

    this.saveToLocalStorage();
  }

  saveToLocalStorage(): void {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      const dataArray = Array.from(data);
      localStorage.setItem('pos_database', JSON.stringify(dataArray));
    } catch (error) {
      console.error('Failed to save database to localStorage:', error);
    }
  }

  // Authentication
  async authenticateUser(username: string, password: string): Promise<any | null> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare('SELECT * FROM users WHERE username = ? AND password = ? AND isActive = 1');
    stmt.bind([username, password]);
    
    let user = null;
    if (stmt.step()) {
      const row = stmt.getAsObject();
      user = {
        ...row,
        isActive: Boolean(row.isActive),
        createdAt: new Date(row.createdAt as string)
      };
    }
    
    stmt.free();
    return user;
  }

  // Branch operations
  async getBranches(): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare('SELECT * FROM branches WHERE isActive = 1 ORDER BY name');
    const branches = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject();
      branches.push({
        ...row,
        settings: JSON.parse(row.settings as string),
        isActive: Boolean(row.isActive),
        createdAt: new Date(row.createdAt as string)
      });
    }
    
    stmt.free();
    return branches;
  }

  async createBranch(branch: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    this.db.run(`
      INSERT INTO branches (id, name, address, phone, email, isActive, managerId, settings, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      branch.id,
      branch.name,
      branch.address,
      branch.phone,
      branch.email,
      branch.isActive ? 1 : 0,
      branch.managerId,
      JSON.stringify(branch.settings),
      branch.createdAt.toISOString()
    ]);
    
    this.saveToLocalStorage();
  }

  // User operations
  async getUsers(branchId?: string): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    let query = 'SELECT * FROM users WHERE isActive = 1';
    const params = [];
    
    if (branchId) {
      query += ' AND branchId = ?';
      params.push(branchId);
    }
    
    query += ' ORDER BY firstName, lastName';
    
    const stmt = this.db.prepare(query);
    if (params.length > 0) {
      stmt.bind(params);
    }
    
    const users = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject();
      users.push({
        ...row,
        isActive: Boolean(row.isActive),
        createdAt: new Date(row.createdAt as string)
      });
    }
    
    stmt.free();
    return users;
  }

  async createUser(user: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    this.db.run(`
      INSERT INTO users (id, username, email, role, firstName, lastName, isActive, password, branchId, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      user.id,
      user.username,
      user.email,
      user.role,
      user.firstName,
      user.lastName,
      user.isActive ? 1 : 0,
      user.password,
      user.branchId,
      user.createdAt.toISOString()
    ]);
    
    this.saveToLocalStorage();
  }

  async updateUser(user: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    this.db.run(`
      UPDATE users 
      SET username = ?, email = ?, role = ?, firstName = ?, lastName = ?, isActive = ?, password = ?, branchId = ?
      WHERE id = ?
    `, [
      user.username,
      user.email,
      user.role,
      user.firstName,
      user.lastName,
      user.isActive ? 1 : 0,
      user.password,
      user.branchId,
      user.id
    ]);
    
    this.saveToLocalStorage();
  }

  async deleteUser(userId: string): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    this.db.run('UPDATE users SET isActive = 0 WHERE id = ?', [userId]);
    this.saveToLocalStorage();
  }

  // Category operations
  async getCategories(branchId: string): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare('SELECT * FROM categories WHERE branchId = ? AND isActive = 1 ORDER BY sortOrder');
    stmt.bind([branchId]);
    
    const categories = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject();
      categories.push({
        ...row,
        isActive: Boolean(row.isActive),
        createdAt: new Date(row.createdAt as string)
      });
    }
    
    stmt.free();
    return categories;
  }

  // Product operations
  async getProducts(branchId: string): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare('SELECT * FROM products WHERE branchId = ? ORDER BY name');
    stmt.bind([branchId]);
    
    const products = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject();
      products.push({
        ...row,
        variants: JSON.parse(row.variants as string || '[]'),
        isActive: Boolean(row.isActive),
        createdAt: new Date(row.createdAt as string)
      });
    }
    
    stmt.free();
    return products;
  }

  async createProduct(product: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    this.db.run(`
      INSERT INTO products (id, name, description, categoryId, category, basePrice, image, isActive, stock, minStock, variants, branchId, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      product.id,
      product.name,
      product.description,
      product.categoryId,
      product.category,
      product.basePrice,
      product.image,
      product.isActive ? 1 : 0,
      product.stock,
      product.minStock,
      JSON.stringify(product.variants),
      product.branchId,
      new Date().toISOString()
    ]);
    
    this.saveToLocalStorage();
  }

  // Order operations
  async getOrders(branchId: string): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare('SELECT * FROM orders WHERE branchId = ? ORDER BY createdAt DESC');
    stmt.bind([branchId]);
    
    const orders = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject();
      orders.push({
        ...row,
        items: JSON.parse(row.items as string),
        createdAt: new Date(row.createdAt as string),
        completedAt: new Date(row.completedAt as string)
      });
    }
    
    stmt.free();
    return orders;
  }

  async createOrder(order: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    this.db.run(`
      INSERT INTO orders (id, orderNumber, items, subtotal, tax, discount, total, paymentMethod, status, customerName, customerNote, cashierId, cashierName, branchId, createdAt, completedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      order.id,
      order.orderNumber,
      JSON.stringify(order.items),
      order.subtotal,
      order.tax,
      order.discount,
      order.total,
      order.paymentMethod,
      order.status,
      order.customerName,
      order.customerNote,
      order.cashierId,
      order.cashierName,
      order.branchId,
      order.createdAt.toISOString(),
      order.completedAt.toISOString()
    ]);
    
    this.saveToLocalStorage();
  }

  // Customer operations
  async getCustomers(branchId: string): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare('SELECT * FROM customers WHERE branchId = ? ORDER BY name');
    stmt.bind([branchId]);
    
    const customers = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject();
      customers.push({
        ...row,
        lastVisit: new Date(row.lastVisit as string),
        createdAt: new Date(row.createdAt as string)
      });
    }
    
    stmt.free();
    return customers;
  }

  // Export database
  exportDatabase(): Uint8Array {
    if (!this.db) throw new Error('Database not initialized');
    return this.db.export();
  }

  // Import database
  async importDatabase(data: Uint8Array): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file) => `https://sql.js.org/dist/${file}`
      });
      
      this.db = new SQL.Database(data);
      this.saveToLocalStorage();
      console.log('✅ Database imported successfully');
    } catch (error) {
      console.error('❌ Failed to import database:', error);
      throw error;
    }
  }
}

export const dbService = new DatabaseService();