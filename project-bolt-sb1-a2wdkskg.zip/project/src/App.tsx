import React, { useState, useEffect } from 'react';
import { AppProvider } from './context/AppContext';
import { LoginForm } from './components/Auth/LoginForm';
import { Sidebar } from './components/Layout/Sidebar';
import { Header } from './components/Layout/Header';
import { MenuView } from './views/MenuView';
import { ProductsView } from './views/ProductsView';
import { OrdersView } from './views/OrdersView';
import { CustomersView } from './views/CustomersView';
import { ReportsView } from './views/ReportsView';
import { BranchesView } from './views/BranchesView';
import { SettingsView } from './views/SettingsView';
import { useAuth } from './hooks/useAuth';
import { useApp } from './context/AppContext';

function AppContent() {
  const { user } = useAuth();
  const { state, dispatch } = useApp();
  const [currentView, setCurrentView] = useState('menu');
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    // Apply theme from settings
    const applyTheme = () => {
      if (state.settings.theme === 'dark') {
        setIsDark(true);
        document.documentElement.classList.add('dark');
      } else {
        setIsDark(false);
        document.documentElement.classList.remove('dark');
      }
    };

    applyTheme();
  }, [state.settings.theme]);

  useEffect(() => {
    // Apply RTL for Arabic
    if (state.settings.language === 'ar') {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = state.settings.language;
    }
  }, [state.settings.language]);

  const toggleTheme = () => {
    const newTheme = !isDark ? 'dark' : 'light';
    const newSettings = { ...state.settings, theme: newTheme };
    
    // Update settings in context
    dispatch({ type: 'SET_SETTINGS', payload: newSettings });
    
    // Save to localStorage
    localStorage.setItem('app_settings', JSON.stringify(newSettings));
    
    // Apply theme immediately
    setIsDark(!isDark);
    if (!isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const getViewTitle = () => {
    switch (currentView) {
      case 'menu': return 'Menu';
      case 'products': return 'Products';
      case 'orders': return 'Orders';
      case 'customers': return 'Customers';
      case 'reports': return 'Reports';
      case 'branches': return 'Branches';
      case 'settings': return 'Settings';
      default: return 'Menu';
    }
  };

  const renderView = () => {
    switch (currentView) {
      case 'menu': return <MenuView />;
      case 'products': return <ProductsView />;
      case 'orders': return <OrdersView />;
      case 'customers': return <CustomersView />;
      case 'reports': return <ReportsView />;
      case 'branches': return <BranchesView />;
      case 'settings': return <SettingsView />;
      default: return <MenuView />;
    }
  };

  if (!user) {
    return <LoginForm />;
  }

  return (
    <div className={`flex h-screen bg-gray-50 dark:bg-gray-900 ${state.settings.language === 'ar' ? 'font-arabic' : ''}`}>
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={getViewTitle()} onThemeToggle={toggleTheme} isDark={isDark} />
        <main className="flex-1 overflow-y-auto p-6">
          {renderView()}
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;