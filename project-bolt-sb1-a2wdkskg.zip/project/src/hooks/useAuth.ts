import { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { dbService } from '../services/database';
import { User } from '../types';

export function useAuth() {
  const { state, dispatch } = useApp();

  const login = async (username: string, password: string): Promise<boolean> => {
    dispatch({ type: 'SET_LOADING', payload: true });
    
    try {
      // Find user across all branches
      const user = await dbService.authenticateUser(username, password);
      
      if (user) {
        // Remove password from user object before storing
        const { password: _, ...userWithoutPassword } = user;
        
        // Set the user
        dispatch({ type: 'SET_USER', payload: userWithoutPassword });
        
        // Switch to user's branch automatically
        const newSettings = { ...state.settings, currentBranchId: user.branchId };
        dispatch({ type: 'SET_SETTINGS', payload: newSettings });
        localStorage.setItem('app_settings', JSON.stringify(newSettings));
        
        // Load branch-specific data
        await loadBranchData(user.branchId);
        
        // Store user session
        localStorage.setItem('user', JSON.stringify(userWithoutPassword));
        localStorage.setItem('currentBranchId', user.branchId);
        
        console.log(`✅ User ${username} logged in to branch: ${user.branchId}`);
        
        dispatch({ type: 'SET_LOADING', payload: false });
        return true;
      }
      
      dispatch({ type: 'SET_LOADING', payload: false });
      return false;
    } catch (error) {
      console.error('Login failed:', error);
      dispatch({ type: 'SET_LOADING', payload: false });
      return false;
    }
  };

  const loadBranchData = async (branchId: string) => {
    try {
      // Load users for the branch
      const users = await dbService.getUsers(branchId);
      dispatch({ type: 'SET_USERS', payload: users });
      
      // Load products for the branch
      const products = await dbService.getProducts(branchId);
      dispatch({ type: 'SET_PRODUCTS', payload: products });
      
      // Load categories for the branch
      const categories = await dbService.getCategories(branchId);
      dispatch({ type: 'SET_CATEGORIES', payload: categories });
      
      // Load orders for the branch
      const orders = await dbService.getOrders(branchId);
      dispatch({ type: 'SET_ORDERS', payload: orders });
      
      // Load customers for the branch
      const customers = await dbService.getCustomers(branchId);
      dispatch({ type: 'SET_CUSTOMERS', payload: customers });
      
      console.log(`✅ Loaded data for branch: ${branchId}`);
    } catch (error) {
      console.error('Failed to load branch data:', error);
    }
  };

  const logout = () => {
    dispatch({ type: 'SET_USER', payload: null });
    localStorage.removeItem('user');
    localStorage.removeItem('currentBranchId');
    
    // Clear branch-specific data
    dispatch({ type: 'SET_USERS', payload: [] });
    dispatch({ type: 'SET_PRODUCTS', payload: [] });
    dispatch({ type: 'SET_CATEGORIES', payload: [] });
    dispatch({ type: 'SET_ORDERS', payload: [] });
    dispatch({ type: 'SET_CUSTOMERS', payload: [] });
  };

  const checkAuth = async () => {
    const savedUser = localStorage.getItem('user');
    const savedBranchId = localStorage.getItem('currentBranchId');
    
    if (savedUser && savedBranchId) {
      try {
        const user = JSON.parse(savedUser);
        dispatch({ type: 'SET_USER', payload: user });
        
        // Update settings with saved branch
        const newSettings = { ...state.settings, currentBranchId: savedBranchId };
        dispatch({ type: 'SET_SETTINGS', payload: newSettings });
        
        // Load branch data
        await loadBranchData(savedBranchId);
      } catch (error) {
        console.error('Failed to restore session:', error);
        logout();
      }
    }
  };

  const switchBranch = async (branchId: string) => {
    if (state.user && state.user.role === 'owner') {
      // Only owners can switch branches
      const newSettings = { ...state.settings, currentBranchId: branchId };
      dispatch({ type: 'SET_SETTINGS', payload: newSettings });
      localStorage.setItem('app_settings', JSON.stringify(newSettings));
      localStorage.setItem('currentBranchId', branchId);
      
      // Load new branch data
      await loadBranchData(branchId);
      
      console.log(`✅ Switched to branch: ${branchId}`);
      return true;
    }
    return false;
  };

  useEffect(() => {
    // Only run checkAuth after the database is ready
    if (state.isDbReady) {
      checkAuth();
    }
  }, [state.isDbReady]);

  return {
    user: state.user,
    login,
    logout,
    switchBranch,
    loadBranchData,
    isLoading: state.isLoading
  };
}