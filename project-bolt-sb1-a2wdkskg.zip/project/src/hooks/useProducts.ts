import { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';

export function useProducts() {
  const { state, dispatch } = useApp();

  const loadProducts = () => {
    // Check if products are already loaded from localStorage
    const savedProducts = localStorage.getItem('app_products');
    if (savedProducts) {
      try {
        const products = JSON.parse(savedProducts);
        dispatch({ type: 'SET_PRODUCTS', payload: products });
        return;
      } catch (error) {
        console.error('Failed to load products from localStorage:', error);
      }
    }

    // Mock data - in real app, this would be from API
    const mockProducts: Product[] = [
      {
        id: '1',
        name: 'Vanilla Soft Serve',
        description: 'Classic vanilla soft serve ice cream',
        categoryId: '1',
        category: 'Soft Ice Cream',
        basePrice: 4.99,
        image: 'https://images.pexels.com/photos/1362534/pexels-photo-1362534.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        stock: 50,
        minStock: 10,
        variants: [
          { id: 'v1', name: 'Cup', price: 0, type: 'container' },
          { id: 'v2', name: 'Cone', price: 0.5, type: 'container' },
          { id: 'v3', name: 'Small', price: 0, type: 'size' },
          { id: 'v4', name: 'Medium', price: 1.5, type: 'size' },
          { id: 'v5', name: 'Large', price: 3.0, type: 'size' }
        ]
      },
      {
        id: '2',
        name: 'Chocolate Soft Serve',
        description: 'Rich chocolate soft serve ice cream',
        categoryId: '1',
        category: 'Soft Ice Cream',
        basePrice: 5.49,
        image: 'https://images.pexels.com/photos/2373520/pexels-photo-2373520.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        stock: 45,
        minStock: 10,
        variants: [
          { id: 'v1', name: 'Cup', price: 0, type: 'container' },
          { id: 'v2', name: 'Cone', price: 0.5, type: 'container' },
          { id: 'v3', name: 'Small', price: 0, type: 'size' },
          { id: 'v4', name: 'Medium', price: 1.5, type: 'size' },
          { id: 'v5', name: 'Large', price: 3.0, type: 'size' }
        ]
      },
      {
        id: '3',
        name: 'Organic Strawberry',
        description: 'Natural strawberry ice cream with real fruit',
        categoryId: '2',
        category: 'Natural Ice Cream',
        basePrice: 6.99,
        image: 'https://images.pexels.com/photos/1352278/pexels-photo-1352278.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        stock: 30,
        minStock: 10,
        variants: [
          { id: 'v1', name: 'Cup', price: 0, type: 'container' },
          { id: 'v2', name: 'Cone', price: 0.5, type: 'container' },
          { id: 'v3', name: 'Small', price: 0, type: 'size' },
          { id: 'v4', name: 'Medium', price: 1.5, type: 'size' },
          { id: 'v5', name: 'Large', price: 3.0, type: 'size' }
        ]
      },
      {
        id: '4',
        name: 'Pistachio Gelato',
        description: 'Authentic Italian pistachio gelato',
        categoryId: '3',
        category: 'Italian Ice Cream',
        basePrice: 7.99,
        image: 'https://images.pexels.com/photos/1294943/pexels-photo-1294943.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        stock: 25,
        minStock: 5,
        variants: [
          { id: 'v1', name: 'Cup', price: 0, type: 'container' },
          { id: 'v2', name: 'Cone', price: 0.5, type: 'container' },
          { id: 'v3', name: 'Small', price: 0, type: 'size' },
          { id: 'v4', name: 'Medium', price: 1.5, type: 'size' },
          { id: 'v5', name: 'Large', price: 3.0, type: 'size' }
        ]
      },
      {
        id: '5',
        name: 'Fresh Orange Juice',
        description: 'Freshly squeezed orange juice',
        categoryId: '4',
        category: 'Juices',
        basePrice: 3.99,
        image: 'https://images.pexels.com/photos/1343502/pexels-photo-1343502.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        stock: 40,
        minStock: 10,
        variants: [
          { id: 'v6', name: 'Small', price: 0, type: 'size' },
          { id: 'v7', name: 'Medium', price: 1.0, type: 'size' },
          { id: 'v8', name: 'Large', price: 2.0, type: 'size' }
        ]
      },
      {
        id: '6',
        name: 'Rainbow Sprinkles',
        description: 'Colorful rainbow sprinkles',
        categoryId: '5',
        category: 'Toppings',
        basePrice: 0.50,
        image: 'https://images.pexels.com/photos/1332306/pexels-photo-1332306.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        stock: 100,
        minStock: 20,
        variants: []
      },
      {
        id: '7',
        name: 'Hot Fudge',
        description: 'Warm chocolate fudge sauce',
        categoryId: '5',
        category: 'Toppings',
        basePrice: 1.00,
        image: 'https://images.pexels.com/photos/918327/pexels-photo-918327.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        stock: 50,
        minStock: 10,
        variants: []
      }
    ];

    dispatch({ type: 'SET_PRODUCTS', payload: mockProducts });
    // Save to localStorage
    localStorage.setItem('app_products', JSON.stringify(mockProducts));
  };

  useEffect(() => {
    if (state.products.length === 0) {
      loadProducts();
    }
  }, []);

  const addProduct = (product: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString()
    };
    
    dispatch({ type: 'ADD_PRODUCT', payload: newProduct });
    
    // Save to localStorage
    const updatedProducts = [...state.products, newProduct];
    localStorage.setItem('app_products', JSON.stringify(updatedProducts));
  };

  const updateProduct = (product: Product) => {
    dispatch({ type: 'UPDATE_PRODUCT', payload: product });
    
    // Save to localStorage
    const updatedProducts = state.products.map(p => p.id === product.id ? product : p);
    localStorage.setItem('app_products', JSON.stringify(updatedProducts));
  };

  const deleteProduct = (id: string) => {
    dispatch({ type: 'DELETE_PRODUCT', payload: id });
    
    // Save to localStorage
    const updatedProducts = state.products.filter(p => p.id !== id);
    localStorage.setItem('app_products', JSON.stringify(updatedProducts));
  };

  return {
    products: state.products,
    addProduct,
    updateProduct,
    deleteProduct
  };
}