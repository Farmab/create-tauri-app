import { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Category } from '../types';

export function useCategories() {
  const { state, dispatch } = useApp();

  const loadCategories = () => {
    // Mock data - in real app, this would be from API
    const mockCategories: Category[] = [
      {
        id: '1',
        name: 'Soft Ice Cream',
        description: 'Creamy soft serve ice cream varieties',
        isActive: true,
        sortOrder: 1,
        createdAt: new Date()
      },
      {
        id: '2',
        name: 'Natural Ice Cream',
        description: 'All-natural ice cream made with organic ingredients',
        isActive: true,
        sortOrder: 2,
        createdAt: new Date()
      },
      {
        id: '3',
        name: 'Italian Ice Cream',
        description: 'Authentic Italian gelato and ice cream',
        isActive: true,
        sortOrder: 3,
        createdAt: new Date()
      },
      {
        id: '4',
        name: 'Juices',
        description: 'Fresh fruit juices and smoothies',
        isActive: true,
        sortOrder: 4,
        createdAt: new Date()
      },
      {
        id: '5',
        name: 'Toppings',
        description: 'Delicious toppings and add-ons',
        isActive: true,
        sortOrder: 5,
        createdAt: new Date()
      }
    ];

    dispatch({ type: 'SET_CATEGORIES', payload: mockCategories });
  };

  useEffect(() => {
    loadCategories();
  }, []);

  const addCategory = (category: Omit<Category, 'id' | 'createdAt'>) => {
    const newCategory: Category = {
      ...category,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    dispatch({ type: 'ADD_CATEGORY', payload: newCategory });
  };

  const updateCategory = (category: Category) => {
    dispatch({ type: 'UPDATE_CATEGORY', payload: category });
  };

  const deleteCategory = (id: string) => {
    dispatch({ type: 'DELETE_CATEGORY', payload: id });
  };

  return {
    categories: state.categories,
    addCategory,
    updateCategory,
    deleteCategory
  };
}