import React, { createContext, useContext, useReducer, ReactNode, useEffect } from 'react';
import { User, Product, Order, AppSettings, Customer, InventoryItem, ColorPalette, Category, Branch } from '../types';
import { dbService } from '../services/database';

interface AppState {
  user: User | null;
  users: User[];
  products: Product[];
  categories: Category[];
  orders: Order[];
  customers: Customer[];
  inventory: InventoryItem[];
  branches: Branch[];
  settings: AppSettings;
  currentOrder: Order | null;
  isLoading: boolean;
  isDbReady: boolean;
}

type AppAction =
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_USERS'; payload: User[] }
  | { type: 'ADD_USER'; payload: User }
  | { type: 'UPDATE_USER'; payload: User }
  | { type: 'DELETE_USER'; payload: string }
  | { type: 'SET_PRODUCTS'; payload: Product[] }
  | { type: 'ADD_PRODUCT'; payload: Product }
  | { type: 'UPDATE_PRODUCT'; payload: Product }
  | { type: 'DELETE_PRODUCT'; payload: string }
  | { type: 'SET_CATEGORIES'; payload: Category[] }
  | { type: 'ADD_CATEGORY'; payload: Category }
  | { type: 'UPDATE_CATEGORY'; payload: Category }
  | { type: 'DELETE_CATEGORY'; payload: string }
  | { type: 'SET_ORDERS'; payload: Order[] }
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'UPDATE_ORDER'; payload: Order }
  | { type: 'SET_CURRENT_ORDER'; payload: Order | null }
  | { type: 'SET_CUSTOMERS'; payload: Customer[] }
  | { type: 'ADD_CUSTOMER'; payload: Customer }
  | { type: 'SET_INVENTORY'; payload: InventoryItem[] }
  | { type: 'UPDATE_INVENTORY'; payload: InventoryItem }
  | { type: 'SET_BRANCHES'; payload: Branch[] }
  | { type: 'ADD_BRANCH'; payload: Branch }
  | { type: 'UPDATE_BRANCH'; payload: Branch }
  | { type: 'SET_SETTINGS'; payload: AppSettings }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_DB_READY'; payload: boolean };

const defaultColorPalette: ColorPalette = {
  id: 'blue',
  name: 'Ocean Blue',
  primary: 'from-blue-500 to-cyan-600',
  secondary: 'from-blue-600 to-cyan-700',
  gradient: 'bg-gradient-to-r from-blue-500 to-cyan-600'
};

const initialState: AppState = {
  user: null,
  users: [],
  products: [],
  categories: [],
  orders: [],
  customers: [],
  inventory: [],
  branches: [],
  settings: {
    businessName: 'Ice Cream Paradise',
    taxRate: 0,
    currency: 'IQD',
    theme: 'light',
    language: 'ku',
    receiptFooter: 'Thank you for your visit!',
    colorPalette: defaultColorPalette,
    currentBranchId: 'branch-1'
  },
  currentOrder: null,
  isLoading: false,
  isDbReady: false
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'SET_USERS':
      return { ...state, users: action.payload };
    case 'ADD_USER':
      return { ...state, users: [...state.users, action.payload] };
    case 'UPDATE_USER':
      return {
        ...state,
        users: state.users.map(u => u.id === action.payload.id ? action.payload : u)
      };
    case 'DELETE_USER':
      return {
        ...state,
        users: state.users.filter(u => u.id !== action.payload)
      };
    case 'SET_PRODUCTS':
      return { ...state, products: action.payload };
    case 'ADD_PRODUCT':
      return { ...state, products: [...state.products, action.payload] };
    case 'UPDATE_PRODUCT':
      return {
        ...state,
        products: state.products.map(p => p.id === action.payload.id ? action.payload : p)
      };
    case 'DELETE_PRODUCT':
      return {
        ...state,
        products: state.products.filter(p => p.id !== action.payload)
      };
    case 'SET_CATEGORIES':
      return { ...state, categories: action.payload };
    case 'ADD_CATEGORY':
      return { ...state, categories: [...state.categories, action.payload] };
    case 'UPDATE_CATEGORY':
      return {
        ...state,
        categories: state.categories.map(c => c.id === action.payload.id ? action.payload : c)
      };
    case 'DELETE_CATEGORY':
      return {
        ...state,
        categories: state.categories.filter(c => c.id !== action.payload)
      };
    case 'SET_ORDERS':
      return { ...state, orders: action.payload };
    case 'ADD_ORDER':
      return { ...state, orders: [action.payload, ...state.orders] };
    case 'UPDATE_ORDER':
      return {
        ...state,
        orders: state.orders.map(o => o.id === action.payload.id ? action.payload : o)
      };
    case 'SET_CURRENT_ORDER':
      return { ...state, currentOrder: action.payload };
    case 'SET_CUSTOMERS':
      return { ...state, customers: action.payload };
    case 'ADD_CUSTOMER':
      return { ...state, customers: [...state.customers, action.payload] };
    case 'SET_INVENTORY':
      return { ...state, inventory: action.payload };
    case 'UPDATE_INVENTORY':
      return {
        ...state,
        inventory: state.inventory.map(i => i.id === action.payload.id ? action.payload : i)
      };
    case 'SET_BRANCHES':
      return { ...state, branches: action.payload };
    case 'ADD_BRANCH':
      return { ...state, branches: [...state.branches, action.payload] };
    case 'UPDATE_BRANCH':
      return {
        ...state,
        branches: state.branches.map(b => b.id === action.payload.id ? action.payload : b)
      };
    case 'SET_SETTINGS':
      return { ...state, settings: action.payload };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_DB_READY':
      return { ...state, isDbReady: action.payload };
    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Initialize database and load data
  useEffect(() => {
    const initializeApp = async () => {
      try {
        dispatch({ type: 'SET_LOADING', payload: true });
        
        // Initialize SQLite database
        await dbService.initialize();
        
        // Load branches
        const branches = await dbService.getBranches();
        dispatch({ type: 'SET_BRANCHES', payload: branches });
        
        // Load users for current branch
        const users = await dbService.getUsers(state.settings.currentBranchId);
        dispatch({ type: 'SET_USERS', payload: users });
        
        // Load products for current branch
        const products = await dbService.getProducts(state.settings.currentBranchId);
        dispatch({ type: 'SET_PRODUCTS', payload: products });
        
        // Load orders for current branch
        const orders = await dbService.getOrders(state.settings.currentBranchId);
        dispatch({ type: 'SET_ORDERS', payload: orders });
        
        // Mark database as ready
        dispatch({ type: 'SET_DB_READY', payload: true });
        
        console.log('✅ App initialized with SQLite database');
      } catch (error) {
        console.error('❌ Failed to initialize app:', error);
      } finally {
        dispatch({ type: 'SET_LOADING', payload: false });
      }
    };

    initializeApp();
  }, []);

  // Load settings from localStorage on startup
  useEffect(() => {
    const savedSettings = localStorage.getItem('app_settings');
    if (savedSettings) {
      try {
        const settings = JSON.parse(savedSettings);
        // Ensure color palette exists and currency is IQD by default
        if (!settings.colorPalette) {
          settings.colorPalette = defaultColorPalette;
        }
        if (!settings.currency) {
          settings.currency = 'IQD';
        }
        if (!settings.language) {
          settings.language = 'ku';
        }
        if (!settings.currentBranchId) {
          settings.currentBranchId = 'branch-1';
        }
        // Set tax rate to 0
        settings.taxRate = 0;
        dispatch({ type: 'SET_SETTINGS', payload: settings });
        
        // Apply theme immediately
        if (settings.theme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      } catch (error) {
        console.error('Failed to load settings:', error);
      }
    }
  }, []);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}