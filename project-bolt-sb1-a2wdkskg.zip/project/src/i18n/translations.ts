export interface Translation {
  // Navigation
  menu: string;
  products: string;
  orders: string;
  customers: string;
  reports: string;
  settings: string;
  signOut: string;

  // Common
  save: string;
  cancel: string;
  delete: string;
  edit: string;
  add: string;
  search: string;
  loading: string;
  yes: string;
  no: string;
  close: string;
  back: string;
  next: string;
  previous: string;
  total: string;
  subtotal: string;
  tax: string;
  quantity: string;
  price: string;
  name: string;
  description: string;
  category: string;
  status: string;
  date: string;
  actions: string;
  each: string;
  receipt: string;

  // Auth
  signIn: string;
  username: string;
  password: string;
  invalidCredentials: string;
  fillAllFields: string;
  signingIn: string;
  demoCredentials: string;

  // Menu/POS
  currentOrder: string;
  addToOrder: string;
  clearOrder: string;
  clearAll: string;
  proceedToCheckout: string;
  printOrder: string;
  noItemsInOrder: string;
  selectProducts: string;
  selectQuantity: string;
  clickToAdd: string;
  recentOrders: string;
  noRecentOrders: string;
  categories: string;
  allItems: string;
  stock: string;

  // Products
  manageProducts: string;
  addProduct: string;
  editProduct: string;
  createProduct: string;
  updateProduct: string;
  productName: string;
  basePrice: string;
  stockQuantity: string;
  minStockAlert: string;
  activeProduct: string;
  productImage: string;
  uploadImage: string;
  noProducts: string;
  lowStockAlert: string;
  productsLowStock: string;
  manageCategories: string;
  productNameRequired: string;
  categoryRequired: string;
  basePriceRequired: string;
  stockRequired: string;
  minStockRequired: string;
  selectCategory: string;
  productDescription: string;
  noProductsFound: string;
  confirmDeleteProduct: string;

  // Categories
  categoryManagement: string;
  addCategory: string;
  editCategory: string;
  createCategory: string;
  updateCategory: string;
  categoryName: string;
  sortOrder: string;
  active: string;
  inactive: string;
  noCategories: string;

  // Orders
  trackOrders: string;
  orderNumber: string;
  customer: string;
  items: string;
  payment: string;
  cashier: string;
  completed: string;
  cancelled: string;
  refunded: string;
  walkInCustomer: string;
  orderDetails: string;
  viewDetails: string;
  printReceipt: string;
  cancelOrder: string;
  refundOrder: string;
  confirmCancel: string;
  confirmRefund: string;
  noOrders: string;

  // Customers
  manageCustomers: string;
  addCustomer: string;
  totalCustomers: string;
  avgLoyaltyPoints: string;
  activeThisMonth: string;
  loyaltyPoints: string;
  totalSpent: string;
  totalOrders: string;
  lastVisit: string;
  memberSince: string;
  viewProfile: string;
  sendMessage: string;
  noCustomers: string;

  // Reports
  reportsAnalytics: string;
  exportReport: string;
  totalRevenue: string;
  avgOrderValue: string;
  itemsSold: string;
  salesOverTime: string;
  paymentMethods: string;
  topSellingProducts: string;
  today: string;
  last7Days: string;
  last30Days: string;
  customRange: string;
  to: string;

  // Settings
  configureSystem: string;
  saveChanges: string;
  businessInfo: string;
  systemName: string;
  systemLogo: string;
  uploadLogo: string;
  currency: string;
  language: string;
  colorPalette: string;
  chooseColorScheme: string;
  taxPricing: string;
  taxRate: string;
  receiptFooter: string;
  receiptMessage: string;
  theme: string;
  displayMode: string;
  light: string;
  dark: string;
  securitySettings: string;
  requirePinVoids: string;
  requireManagerPin: string;
  autoLogout: string;
  autoLogoutInactivity: string;
  auditLogging: string;
  logSystemActions: string;
  syncStatus: string;
  connection: string;
  online: string;
  offline: string;
  pendingOrders: string;
  lastSync: string;
  never: string;
  syncNow: string;
  syncing: string;

  // User Management
  userManagement: string;
  manageUsers: string;
  systemUsers: string;
  addUser: string;
  editUser: string;
  addNewUser: string;
  createUser: string;
  updateUser: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  confirmPassword: string;
  activeUser: string;
  noUsers: string;
  admin: string;
  cashier: string;
  manager: string;
  owner: string;
  usernameRequired: string;
  usernameExists: string;
  emailRequired: string;
  emailInvalid: string;
  firstNameRequired: string;
  lastNameRequired: string;
  passwordRequired: string;
  passwordMinLength: string;
  passwordsNotMatch: string;
  leaveBlankToKeep: string;
  confirmDeleteUser: string;

  // Color Palettes
  oceanBlue: string;
  royalPurple: string;
  forestGreen: string;
  sunsetOrange: string;
  tropicalTeal: string;
  deepIndigo: string;

  // Receipt
  thankYou: string;
  orderCompleted: string;
}

export const translations: Record<string, Translation> = {
  en: {
    // Navigation
    menu: 'Menu',
    products: 'Products',
    orders: 'Orders',
    customers: 'Customers',
    reports: 'Reports',
    settings: 'Settings',
    signOut: 'Sign Out',

    // Common
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    search: 'Search',
    loading: 'Loading',
    yes: 'Yes',
    no: 'No',
    close: 'Close',
    back: 'Back',
    next: 'Next',
    previous: 'Previous',
    total: 'Total',
    subtotal: 'Subtotal',
    tax: 'Tax',
    quantity: 'Quantity',
    price: 'Price',
    name: 'Name',
    description: 'Description',
    category: 'Category',
    status: 'Status',
    date: 'Date',
    actions: 'Actions',
    each: 'each',
    receipt: 'Receipt',

    // Auth
    signIn: 'Sign In',
    username: 'Username',
    password: 'Password',
    invalidCredentials: 'Invalid username or password',
    fillAllFields: 'Please fill in all fields',
    signingIn: 'Signing in...',
    demoCredentials: 'Demo credentials:',

    // Menu/POS
    currentOrder: 'Current Order',
    addToOrder: 'Add to Order',
    clearOrder: 'Clear',
    clearAll: 'Clear All',
    proceedToCheckout: 'Proceed to Checkout',
    printOrder: 'Print Order',
    noItemsInOrder: 'No items in order',
    selectProducts: 'Select products to get started',
    selectQuantity: 'Select Quantity',
    clickToAdd: 'Click any item below to add this quantity',
    recentOrders: 'Recent Orders',
    noRecentOrders: 'No recent orders',
    categories: 'Categories',
    allItems: 'All Items',
    stock: 'Stock',

    // Products
    manageProducts: 'Manage your products and categories',
    addProduct: 'Add Product',
    editProduct: 'Edit Product',
    createProduct: 'Create Product',
    updateProduct: 'Update Product',
    productName: 'Product Name',
    basePrice: 'Base Price',
    stockQuantity: 'Stock Quantity',
    minStockAlert: 'Minimum Stock Alert',
    activeProduct: 'Active Product',
    productImage: 'Product Image',
    uploadImage: 'Upload Image',
    noProducts: 'No products added yet',
    lowStockAlert: 'Low Stock Alert',
    productsLowStock: 'product(s) are running low on stock',
    manageCategories: 'Manage Categories',
    productNameRequired: 'Product name is required',
    categoryRequired: 'Category is required',
    basePriceRequired: 'Base price must be greater than 0',
    stockRequired: 'Stock cannot be negative',
    minStockRequired: 'Minimum stock cannot be negative',
    selectCategory: 'Select a category',
    productDescription: 'Enter product description',
    noProductsFound: 'No products found matching your criteria',
    confirmDeleteProduct: 'Are you sure you want to delete this product?',

    // Categories
    categoryManagement: 'Category Management',
    addCategory: 'Add Category',
    editCategory: 'Edit Category',
    createCategory: 'Create Category',
    updateCategory: 'Update Category',
    categoryName: 'Category Name',
    sortOrder: 'Sort Order',
    active: 'Active',
    inactive: 'Inactive',
    noCategories: 'No categories created yet',

    // Orders
    trackOrders: 'Track and manage customer orders',
    orderNumber: 'Order',
    customer: 'Customer',
    items: 'Items',
    payment: 'Payment',
    cashier: 'Cashier',
    completed: 'Completed',
    cancelled: 'Cancelled',
    refunded: 'Refunded',
    walkInCustomer: 'Walk-in Customer',
    orderDetails: 'Order Details',
    viewDetails: 'View Details',
    printReceipt: 'Print Receipt',
    cancelOrder: 'Cancel Order',
    refundOrder: 'Refund Order',
    confirmCancel: 'Are you sure you want to cancel this order?',
    confirmRefund: 'Are you sure you want to refund this order?',
    noOrders: 'No orders yet',

    // Customers
    manageCustomers: 'Manage customer relationships and loyalty programs',
    addCustomer: 'Add Customer',
    totalCustomers: 'Total Customers',
    avgLoyaltyPoints: 'Avg Loyalty Points',
    activeThisMonth: 'Active This Month',
    loyaltyPoints: 'Loyalty Points',
    totalSpent: 'Total Spent',
    totalOrders: 'Total Orders',
    lastVisit: 'Last Visit',
    memberSince: 'Member since',
    viewProfile: 'View Profile',
    sendMessage: 'Send Message',
    noCustomers: 'No customers registered yet',

    // Reports
    reportsAnalytics: 'Track your sales performance and business insights',
    exportReport: 'Export Report',
    totalRevenue: 'Total Revenue',
    avgOrderValue: 'Avg Order Value',
    itemsSold: 'Items Sold',
    salesOverTime: 'Sales Over Time',
    paymentMethods: 'Payment Methods',
    topSellingProducts: 'Top Selling Products',
    today: 'Today',
    last7Days: 'Last 7 Days',
    last30Days: 'Last 30 Days',
    customRange: 'Custom Range',
    to: 'to',

    // Settings
    configureSystem: 'Configure your POS system preferences',
    saveChanges: 'Save Changes',
    businessInfo: 'Business Information',
    systemName: 'System Name',
    systemLogo: 'System Logo',
    uploadLogo: 'Upload Logo',
    currency: 'Currency',
    language: 'Language',
    colorPalette: 'Color Palette',
    chooseColorScheme: 'Choose a color scheme for your system interface',
    taxPricing: 'Tax & Pricing',
    taxRate: 'Tax Rate (%)',
    receiptFooter: 'Receipt Footer Message',
    receiptMessage: 'Thank you message for receipts...',
    theme: 'Theme',
    displayMode: 'Display Mode',
    light: 'Light',
    dark: 'Dark',
    securitySettings: 'Security Settings',
    requirePinVoids: 'Require PIN for Voids',
    requireManagerPin: 'Require manager PIN to void orders',
    autoLogout: 'Auto Logout',
    autoLogoutInactivity: 'Automatically logout after inactivity',
    auditLogging: 'Audit Logging',
    logSystemActions: 'Log all critical system actions',
    syncStatus: 'Sync Status',
    connection: 'Connection',
    online: 'Online',
    offline: 'Offline',
    pendingOrders: 'Pending Orders',
    lastSync: 'Last Sync',
    never: 'Never',
    syncNow: 'Sync Now',
    syncing: 'Syncing...',

    // User Management
    userManagement: 'User Management',
    manageUsers: 'Manage Users',
    systemUsers: 'System Users',
    addUser: 'Add User',
    editUser: 'Edit User',
    addNewUser: 'Add New User',
    createUser: 'Create User',
    updateUser: 'Update User',
    firstName: 'First Name',
    lastName: 'Last Name',
    email: 'Email',
    role: 'Role',
    confirmPassword: 'Confirm Password',
    activeUser: 'Active User',
    noUsers: 'No users created yet',
    admin: 'Admin',
    cashier: 'Cashier',
    manager: 'Manager',
    owner: 'Owner',
    usernameRequired: 'Username is required',
    usernameExists: 'Username already exists',
    emailRequired: 'Email is required',
    emailInvalid: 'Email is invalid',
    firstNameRequired: 'First name is required',
    lastNameRequired: 'Last name is required',
    passwordRequired: 'Password is required',
    passwordMinLength: 'Password must be at least 6 characters',
    passwordsNotMatch: 'Passwords do not match',
    leaveBlankToKeep: 'Leave blank to keep current password',
    confirmDeleteUser: 'Are you sure you want to delete this user?',

    // Color Palettes
    oceanBlue: 'Ocean Blue',
    royalPurple: 'Royal Purple',
    forestGreen: 'Forest Green',
    sunsetOrange: 'Sunset Orange',
    tropicalTeal: 'Tropical Teal',
    deepIndigo: 'Deep Indigo',

    // Receipt
    thankYou: 'Thank you for your visit!',
    orderCompleted: 'Order completed successfully'
  },

  ku: {
    // Navigation
    menu: 'مێنو',
    products: 'بەرهەمەکان',
    orders: 'داواکاریەکان',
    customers: 'کڕیارەکان',
    reports: 'ڕاپۆرتەکان',
    settings: 'ڕێکخستنەکان',
    signOut: 'دەرچوون',

    // Common
    save: 'پاشەکەوتکردن',
    cancel: 'هەڵوەشاندنەوە',
    delete: 'سڕینەوە',
    edit: 'دەستکاریکردن',
    add: 'زیادکردن',
    search: 'گەڕان',
    loading: 'بارکردن',
    yes: 'بەڵێ',
    no: 'نەخێر',
    close: 'داخستن',
    back: 'گەڕانەوە',
    next: 'دواتر',
    previous: 'پێشتر',
    total: 'کۆی گشتی',
    subtotal: 'کۆی بنەڕەتی',
    tax: 'باج',
    quantity: 'بڕ',
    price: 'نرخ',
    name: 'ناو',
    description: 'وەسف',
    category: 'جۆر',
    status: 'دۆخ',
    date: 'بەروار',
    actions: 'کردارەکان',
    each: 'هەریەک',
    receipt: 'پسوڵە',

    // Auth
    signIn: 'چوونەژوورەوە',
    username: 'ناوی بەکارهێنەر',
    password: 'وشەی نهێنی',
    invalidCredentials: 'ناوی بەکارهێنەر یان وشەی نهێنی هەڵەیە',
    fillAllFields: 'تکایە هەموو خانەکان پڕبکەرەوە',
    signingIn: 'چوونەژوورەوە...',
    demoCredentials: 'زانیاریەکانی تاقیکردنەوە:',

    // Menu/POS
    currentOrder: 'داواکاری ئێستا',
    addToOrder: 'زیادکردن بۆ داواکاری',
    clearOrder: 'پاککردنەوە',
    clearAll: 'پاککردنەوەی هەموو',
    proceedToCheckout: 'بەردەوامبوون بۆ پارەدان',
    printOrder: 'چاپکردنی داواکاری',
    noItemsInOrder: 'هیچ شتێک لە داواکاریدا نییە',
    selectProducts: 'بەرهەمەکان هەڵبژێرە بۆ دەستپێکردن',
    selectQuantity: 'بڕ هەڵبژێرە',
    clickToAdd: 'کلیک لە هەر شتێک بکە بۆ زیادکردنی ئەم بڕە',
    recentOrders: 'داواکاریە نوێیەکان',
    noRecentOrders: 'هیچ داواکاریەکی نوێ نییە',
    categories: 'جۆرەکان',
    allItems: 'هەموو شتەکان',
    stock: 'کۆگا',

    // Products
    manageProducts: 'بەڕێوەبردنی بەرهەمەکان و جۆرەکانت',
    addProduct: 'زیادکردنی بەرهەم',
    editProduct: 'دەستکاریکردنی بەرهەم',
    createProduct: 'دروستکردنی بەرهەم',
    updateProduct: 'نوێکردنەوەی بەرهەم',
    productName: 'ناوی بەرهەم',
    basePrice: 'نرخی بنەڕەتی',
    stockQuantity: 'بڕی کۆگا',
    minStockAlert: 'ئاگاداری کەمترین کۆگا',
    activeProduct: 'بەرهەمی چالاک',
    productImage: 'وێنەی بەرهەم',
    uploadImage: 'بارکردنی وێنە',
    noProducts: 'هێشتا هیچ بەرهەمێک زیادنەکراوە',
    lowStockAlert: 'ئاگاداری کۆگای کەم',
    productsLowStock: 'بەرهەم کۆگایان کەمە',
    manageCategories: 'بەڕێوەبردنی جۆرەکان',
    productNameRequired: 'ناوی بەرهەم پێویستە',
    categoryRequired: 'جۆر پێویستە',
    basePriceRequired: 'نرخی بنەڕەتی دەبێت لە ٠ زیاتر بێت',
    stockRequired: 'کۆگا ناتوانێت نەرێنی بێت',
    minStockRequired: 'کەمترین کۆگا ناتوانێت نەرێنی بێت',
    selectCategory: 'جۆرێک هەڵبژێرە',
    productDescription: 'وەسفی بەرهەم بنووسە',
    noProductsFound: 'هیچ بەرهەمێک نەدۆزرایەوە',
    confirmDeleteProduct: 'دڵنیایت لە سڕینەوەی ئەم بەرهەمە؟',

    // Categories
    categoryManagement: 'بەڕێوەبردنی جۆرەکان',
    addCategory: 'زیادکردنی جۆر',
    editCategory: 'دەستکاریکردنی جۆر',
    createCategory: 'دروستکردنی جۆر',
    updateCategory: 'نوێکردنەوەی جۆر',
    categoryName: 'ناوی جۆر',
    sortOrder: 'ڕیزبەندی',
    active: 'چالاک',
    inactive: 'ناچالاک',
    noCategories: 'هێشتا هیچ جۆرێک دروستنەکراوە',

    // Orders
    trackOrders: 'بەدواداچوون و بەڕێوەبردنی داواکاریەکانی کڕیار',
    orderNumber: 'داواکاری',
    customer: 'کڕیار',
    items: 'شتەکان',
    payment: 'پارەدان',
    cashier: 'فرۆشیار',
    completed: 'تەواوبوو',
    cancelled: 'هەڵوەشێنراوە',
    refunded: 'گەڕێندراوەتەوە',
    walkInCustomer: 'کڕیاری ڕێگەیی',
    orderDetails: 'وردەکاریەکانی داواکاری',
    viewDetails: 'بینینی وردەکاریەکان',
    printReceipt: 'چاپکردنی پسوڵە',
    cancelOrder: 'هەڵوەشاندنەوەی داواکاری',
    refundOrder: 'گەڕاندنەوەی داواکاری',
    confirmCancel: 'دڵنیایت لە هەڵوەشاندنەوەی ئەم داواکارییە؟',
    confirmRefund: 'دڵنیایت لە گەڕاندنەوەی ئەم داواکارییە؟',
    noOrders: 'هێشتا هیچ داواکاریەک نییە',

    // Customers
    manageCustomers: 'بەڕێوەبردنی پەیوەندیەکانی کڕیار و بەرنامەکانی دڵسۆزی',
    addCustomer: 'زیادکردنی کڕیار',
    totalCustomers: 'کۆی کڕیارەکان',
    avgLoyaltyPoints: 'ناوەندی خاڵی دڵسۆزی',
    activeThisMonth: 'چالاک لەم مانگەدا',
    loyaltyPoints: 'خاڵی دڵسۆزی',
    totalSpent: 'کۆی خەرجکراو',
    totalOrders: 'کۆی داواکاریەکان',
    lastVisit: 'دوایین سەردان',
    memberSince: 'ئەندام لە',
    viewProfile: 'بینینی پڕۆفایل',
    sendMessage: 'ناردنی پەیام',
    noCustomers: 'هێشتا هیچ کڕیارێک تۆمارنەکراوە',

    // Reports
    reportsAnalytics: 'بەدواداچوونی ئادایی فرۆشتن و تێگەیشتنی بازرگانی',
    exportReport: 'هەناردەکردنی ڕاپۆرت',
    totalRevenue: 'کۆی داهات',
    avgOrderValue: 'ناوەندی نرخی داواکاری',
    itemsSold: 'شتە فرۆشراوەکان',
    salesOverTime: 'فرۆشتن بەپێی کات',
    paymentMethods: 'ڕێگەکانی پارەدان',
    topSellingProducts: 'بەرهەمە زۆر فرۆشراوەکان',
    today: 'ئەمڕۆ',
    last7Days: 'دوایین ٧ ڕۆژ',
    last30Days: 'دوایین ٣٠ ڕۆژ',
    customRange: 'مەودای تایبەت',
    to: 'بۆ',

    // Settings
    configureSystem: 'ڕێکخستنی ئارەزووەکانی سیستەمی POS',
    saveChanges: 'پاشەکەوتکردنی گۆڕانکاریەکان',
    businessInfo: 'زانیاریەکانی بازرگانی',
    systemName: 'ناوی سیستەم',
    systemLogo: 'لۆگۆی سیستەم',
    uploadLogo: 'بارکردنی لۆگۆ',
    currency: 'دراو',
    language: 'زمان',
    colorPalette: 'پالێتی ڕەنگ',
    chooseColorScheme: 'ڕەنگێک هەڵبژێرە بۆ ڕووکاری سیستەمەکەت',
    taxPricing: 'باج و نرخدانان',
    taxRate: 'ڕێژەی باج (%)',
    receiptFooter: 'پەیامی خوارەوەی پسوڵە',
    receiptMessage: 'پەیامی سوپاسگوزاری بۆ پسوڵەکان...',
    theme: 'ڕووکار',
    displayMode: 'شێوازی پیشاندان',
    light: 'ڕووناک',
    dark: 'تاریک',
    securitySettings: 'ڕێکخستنەکانی ئاسایش',
    requirePinVoids: 'پێویستی بە PIN بۆ هەڵوەشاندنەوە',
    requireManagerPin: 'پێویستی بە PIN ی بەڕێوەبەر بۆ هەڵوەشاندنەوەی داواکاریەکان',
    autoLogout: 'دەرچوونی خۆکار',
    autoLogoutInactivity: 'دەرچوونی خۆکار دوای بێچالاکی',
    auditLogging: 'تۆمارکردنی پشکنین',
    logSystemActions: 'تۆمارکردنی هەموو کردارە گرنگەکانی سیستەم',
    syncStatus: 'دۆخی هاوکاتکردن',
    connection: 'پەیوەندی',
    online: 'سەرهێڵ',
    offline: 'دەرهێڵ',
    pendingOrders: 'داواکاریە چاوەڕوانەکان',
    lastSync: 'دوایین هاوکاتکردن',
    never: 'هەرگیز',
    syncNow: 'ئێستا هاوکات بکە',
    syncing: 'هاوکاتکردن...',

    // User Management
    userManagement: 'بەڕێوەبردنی بەکارهێنەران',
    manageUsers: 'بەڕێوەبردنی بەکارهێنەران',
    systemUsers: 'بەکارهێنەرانی سیستەم',
    addUser: 'زیادکردنی بەکارهێنەر',
    editUser: 'دەستکاریکردنی بەکارهێنەر',
    addNewUser: 'زیادکردنی بەکارهێنەری نوێ',
    createUser: 'دروستکردنی بەکارهێنەر',
    updateUser: 'نوێکردنەوەی بەکارهێنەر',
    firstName: 'ناوی یەکەم',
    lastName: 'ناوی دووەم',
    email: 'ئیمەیڵ',
    role: 'ڕۆڵ',
    confirmPassword: 'دووپاتکردنەوەی وشەی نهێنی',
    activeUser: 'بەکارهێنەری چالاک',
    noUsers: 'هێشتا هیچ بەکارهێنەرێک دروستنەکراوە',
    admin: 'بەڕێوەبەر',
    cashier: 'فرۆشیار',
    manager: 'مەنەجەر',
    owner: 'خاوەن',
    usernameRequired: 'ناوی بەکارهێنەر پێویستە',
    usernameExists: 'ناوی بەکارهێنەر پێشتر هەیە',
    emailRequired: 'ئیمەیڵ پێویستە',
    emailInvalid: 'ئیمەیڵ هەڵەیە',
    firstNameRequired: 'ناوی یەکەم پێویستە',
    lastNameRequired: 'ناوی دووەم پێویستە',
    passwordRequired: 'وشەی نهێنی پێویستە',
    passwordMinLength: 'وشەی نهێنی دەبێت لانیکەم ٦ پیت بێت',
    passwordsNotMatch: 'وشەکانی نهێنی یەکناگرنەوە',
    leaveBlankToKeep: 'بەتاڵی بهێڵەرەوە بۆ هێشتنەوەی وشەی نهێنی ئێستا',
    confirmDeleteUser: 'دڵنیایت لە سڕینەوەی ئەم بەکارهێنەرە؟',

    // Color Palettes
    oceanBlue: 'شینی زەریا',
    royalPurple: 'پەمەیی شاهانە',
    forestGreen: 'سەوزی دارستان',
    sunsetOrange: 'پرتەقاڵی ئاوابوون',
    tropicalTeal: 'شینی گەرمسێری',
    deepIndigo: 'شینی قووڵ',

    // Receipt
    thankYou: 'سوپاس بۆ سەردانەکەت!',
    orderCompleted: 'داواکاری بە سەرکەوتوویی تەواوبوو'
  },

  ar: {
    // Navigation
    menu: 'القائمة',
    products: 'المنتجات',
    orders: 'الطلبات',
    customers: 'العملاء',
    reports: 'التقارير',
    settings: 'الإعدادات',
    signOut: 'تسجيل الخروج',

    // Common
    save: 'حفظ',
    cancel: 'إلغاء',
    delete: 'حذف',
    edit: 'تعديل',
    add: 'إضافة',
    search: 'بحث',
    loading: 'جاري التحميل',
    yes: 'نعم',
    no: 'لا',
    close: 'إغلاق',
    back: 'رجوع',
    next: 'التالي',
    previous: 'السابق',
    total: 'المجموع',
    subtotal: 'المجموع الفرعي',
    tax: 'الضريبة',
    quantity: 'الكمية',
    price: 'السعر',
    name: 'الاسم',
    description: 'الوصف',
    category: 'الفئة',
    status: 'الحالة',
    date: 'التاريخ',
    actions: 'الإجراءات',
    each: 'لكل واحد',
    receipt: 'الإيصال',

    // Auth
    signIn: 'تسجيل الدخول',
    username: 'اسم المستخدم',
    password: 'كلمة المرور',
    invalidCredentials: 'اسم المستخدم أو كلمة المرور غير صحيحة',
    fillAllFields: 'يرجى ملء جميع الحقول',
    signingIn: 'جاري تسجيل الدخول...',
    demoCredentials: 'بيانات التجربة:',

    // Menu/POS
    currentOrder: 'الطلب الحالي',
    addToOrder: 'إضافة للطلب',
    clearOrder: 'مسح',
    clearAll: 'مسح الكل',
    proceedToCheckout: 'المتابعة للدفع',
    printOrder: 'طباعة الطلب',
    noItemsInOrder: 'لا توجد عناصر في الطلب',
    selectProducts: 'اختر المنتجات للبدء',
    selectQuantity: 'اختر الكمية',
    clickToAdd: 'انقر على أي عنصر أدناه لإضافة هذه الكمية',
    recentOrders: 'الطلبات الأخيرة',
    noRecentOrders: 'لا توجد طلبات حديثة',
    categories: 'الفئات',
    allItems: 'جميع العناصر',
    stock: 'المخزون',

    // Products
    manageProducts: 'إدارة منتجاتك وفئاتك',
    addProduct: 'إضافة منتج',
    editProduct: 'تعديل المنتج',
    createProduct: 'إنشاء منتج',
    updateProduct: 'تحديث المنتج',
    productName: 'اسم المنتج',
    basePrice: 'السعر الأساسي',
    stockQuantity: 'كمية المخزون',
    minStockAlert: 'تنبيه الحد الأدنى للمخزون',
    activeProduct: 'منتج نشط',
    productImage: 'صورة المنتج',
    uploadImage: 'رفع صورة',
    noProducts: 'لم يتم إضافة منتجات بعد',
    lowStockAlert: 'تنبيه مخزون منخفض',
    productsLowStock: 'منتج(ات) ينفد مخزونها',
    manageCategories: 'إدارة الفئات',
    productNameRequired: 'اسم المنتج مطلوب',
    categoryRequired: 'الفئة مطلوبة',
    basePriceRequired: 'السعر الأساسي يجب أن يكون أكبر من 0',
    stockRequired: 'المخزون لا يمكن أن يكون سالباً',
    minStockRequired: 'الحد الأدنى للمخزون لا يمكن أن يكون سالباً',
    selectCategory: 'اختر فئة',
    productDescription: 'أدخل وصف المنتج',
    noProductsFound: 'لم يتم العثور على منتجات تطابق معاييرك',
    confirmDeleteProduct: 'هل أنت متأكد من حذف هذا المنتج؟',

    // Categories
    categoryManagement: 'إدارة الفئات',
    addCategory: 'إضافة فئة',
    editCategory: 'تعديل الفئة',
    createCategory: 'إنشاء فئة',
    updateCategory: 'تحديث الفئة',
    categoryName: 'اسم الفئة',
    sortOrder: 'ترتيب الفرز',
    active: 'نشط',
    inactive: 'غير نشط',
    noCategories: 'لم يتم إنشاء فئات بعد',

    // Orders
    trackOrders: 'تتبع وإدارة طلبات العملاء',
    orderNumber: 'الطلب',
    customer: 'العميل',
    items: 'العناصر',
    payment: 'الدفع',
    cashier: 'الكاشير',
    completed: 'مكتمل',
    cancelled: 'ملغي',
    refunded: 'مسترد',
    walkInCustomer: 'عميل مباشر',
    orderDetails: 'تفاصيل الطلب',
    viewDetails: 'عرض التفاصيل',
    printReceipt: 'طباعة الإيصال',
    cancelOrder: 'إلغاء الطلب',
    refundOrder: 'استرداد الطلب',
    confirmCancel: 'هل أنت متأكد من إلغاء هذا الطلب؟',
    confirmRefund: 'هل أنت متأكد من استرداد هذا الطلب؟',
    noOrders: 'لا توجد طلبات بعد',

    // Customers
    manageCustomers: 'إدارة علاقات العملاء وبرامج الولاء',
    addCustomer: 'إضافة عميل',
    totalCustomers: 'إجمالي العملاء',
    avgLoyaltyPoints: 'متوسط نقاط الولاء',
    activeThisMonth: 'نشط هذا الشهر',
    loyaltyPoints: 'نقاط الولاء',
    totalSpent: 'إجمالي المنفق',
    totalOrders: 'إجمالي الطلبات',
    lastVisit: 'آخر زيارة',
    memberSince: 'عضو منذ',
    viewProfile: 'عرض الملف الشخصي',
    sendMessage: 'إرسال رسالة',
    noCustomers: 'لم يتم تسجيل عملاء بعد',

    // Reports
    reportsAnalytics: 'تتبع أداء المبيعات ورؤى الأعمال',
    exportReport: 'تصدير التقرير',
    totalRevenue: 'إجمالي الإيرادات',
    avgOrderValue: 'متوسط قيمة الطلب',
    itemsSold: 'العناصر المباعة',
    salesOverTime: 'المبيعات عبر الوقت',
    paymentMethods: 'طرق الدفع',
    topSellingProducts: 'المنتجات الأكثر مبيعاً',
    today: 'اليوم',
    last7Days: 'آخر 7 أيام',
    last30Days: 'آخر 30 يوماً',
    customRange: 'نطاق مخصص',
    to: 'إلى',

    // Settings
    configureSystem: 'تكوين تفضيلات نظام نقاط البيع',
    saveChanges: 'حفظ التغييرات',
    businessInfo: 'معلومات الأعمال',
    systemName: 'اسم النظام',
    systemLogo: 'شعار النظام',
    uploadLogo: 'رفع الشعار',
    currency: 'العملة',
    language: 'اللغة',
    colorPalette: 'لوحة الألوان',
    chooseColorScheme: 'اختر نظام ألوان لواجهة النظام',
    taxPricing: 'الضرائب والتسعير',
    taxRate: 'معدل الضريبة (%)',
    receiptFooter: 'رسالة تذييل الإيصال',
    receiptMessage: 'رسالة شكر للإيصالات...',
    theme: 'المظهر',
    displayMode: 'وضع العرض',
    light: 'فاتح',
    dark: 'داكن',
    securitySettings: 'إعدادات الأمان',
    requirePinVoids: 'يتطلب رقم سري للإلغاءات',
    requireManagerPin: 'يتطلب رقم سري للمدير لإلغاء الطلبات',
    autoLogout: 'تسجيل خروج تلقائي',
    autoLogoutInactivity: 'تسجيل خروج تلقائي بعد عدم النشاط',
    auditLogging: 'تسجيل المراجعة',
    logSystemActions: 'تسجيل جميع إجراءات النظام الحرجة',
    syncStatus: 'حالة المزامنة',
    connection: 'الاتصال',
    online: 'متصل',
    offline: 'غير متصل',
    pendingOrders: 'الطلبات المعلقة',
    lastSync: 'آخر مزامنة',
    never: 'أبداً',
    syncNow: 'مزامنة الآن',
    syncing: 'جاري المزامنة...',

    // User Management
    userManagement: 'إدارة المستخدمين',
    manageUsers: 'إدارة المستخدمين',
    systemUsers: 'مستخدمو النظام',
    addUser: 'إضافة مستخدم',
    editUser: 'تعديل المستخدم',
    addNewUser: 'إضافة مستخدم جديد',
    createUser: 'إنشاء مستخدم',
    updateUser: 'تحديث المستخدم',
    firstName: 'الاسم الأول',
    lastName: 'الاسم الأخير',
    email: 'البريد الإلكتروني',
    role: 'الدور',
    confirmPassword: 'تأكيد كلمة المرور',
    activeUser: 'مستخدم نشط',
    noUsers: 'لم يتم إنشاء مستخدمين بعد',
    admin: 'مدير',
    cashier: 'كاشير',
    manager: 'مدير',
    owner: 'مالك',
    usernameRequired: 'اسم المستخدم مطلوب',
    usernameExists: 'اسم المستخدم موجود بالفعل',
    emailRequired: 'البريد الإلكتروني مطلوب',
    emailInvalid: 'البريد الإلكتروني غير صحيح',
    firstNameRequired: 'الاسم الأول مطلوب',
    lastNameRequired: 'الاسم الأخير مطلوب',
    passwordRequired: 'كلمة المرور مطلوبة',
    passwordMinLength: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
    passwordsNotMatch: 'كلمات المرور غير متطابقة',
    leaveBlankToKeep: 'اتركه فارغاً للاحتفاظ بكلمة المرور الحالية',
    confirmDeleteUser: 'هل أنت متأكد من حذف هذا المستخدم؟',

    // Color Palettes
    oceanBlue: 'أزرق المحيط',
    royalPurple: 'بنفسجي ملكي',
    forestGreen: 'أخضر الغابة',
    sunsetOrange: 'برتقالي الغروب',
    tropicalTeal: 'أزرق استوائي',
    deepIndigo: 'نيلي عميق',

    // Receipt
    thankYou: 'شكراً لزيارتك!',
    orderCompleted: 'تم إكمال الطلب بنجاح'
  }
};