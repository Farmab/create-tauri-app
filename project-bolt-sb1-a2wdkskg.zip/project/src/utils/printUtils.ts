export interface PrintOptions {
  width?: number;
  fontSize?: number;
  fontFamily?: string;
  lineHeight?: number;
}

export function generate80mmReceipt(order: any, settings: any, isRTL: boolean = false, t: (key: string) => string): string {
  const width = 80; // 80mm width
  const charWidth = 42; // Characters per line for 80mm
  
  const centerText = (text: string) => {
    const padding = Math.max(0, Math.floor((charWidth - text.length) / 2));
    return ' '.repeat(padding) + text;
  };

  const leftRightText = (left: string, right: string) => {
    const totalLength = left.length + right.length;
    const spaces = Math.max(1, charWidth - totalLength);
    return left + ' '.repeat(spaces) + right;
  };

  const line = '='.repeat(charWidth);
  const dottedLine = '-'.repeat(charWidth);

  const formatPrice = (price: number) => {
    if (settings.currency === 'IQD') {
      return `${(price * 1500).toLocaleString()} د.ع`;
    }
    return `$${price.toFixed(2)}`;
  };

  return `
<!DOCTYPE html>
<html dir="${isRTL ? 'rtl' : 'ltr'}" lang="${settings.language}">
<head>
  <meta charset="UTF-8">
  <title>${t('receipt')} - ${order.orderNumber}</title>
  <style>
    @page {
      size: 80mm auto;
      margin: 0;
    }
    
    body {
      font-family: 'Courier New', monospace;
      font-size: 12px;
      line-height: 1.2;
      margin: 0;
      padding: 5mm;
      width: 70mm;
      direction: ${isRTL ? 'rtl' : 'ltr'};
      color: #000;
      background: #fff;
    }
    
    .header {
      text-align: center;
      margin-bottom: 10px;
      border-bottom: 2px solid #000;
      padding-bottom: 5px;
    }
    
    .business-name {
      font-size: 16px;
      font-weight: bold;
      margin-bottom: 2px;
    }
    
    .order-info {
      text-align: center;
      margin-bottom: 8px;
      font-size: 11px;
    }
    
    .items-header {
      border-top: 1px solid #000;
      border-bottom: 1px solid #000;
      padding: 2px 0;
      font-weight: bold;
      font-size: 10px;
    }
    
    .item {
      padding: 1px 0;
      font-size: 10px;
      border-bottom: 1px dotted #ccc;
    }
    
    .item-name {
      font-weight: bold;
    }
    
    .item-details {
      display: flex;
      justify-content: space-between;
      margin-top: 1px;
    }
    
    .totals {
      border-top: 2px solid #000;
      padding-top: 5px;
      margin-top: 5px;
    }
    
    .total-line {
      display: flex;
      justify-content: space-between;
      margin: 1px 0;
    }
    
    .grand-total {
      border-top: 1px solid #000;
      border-bottom: 1px solid #000;
      padding: 2px 0;
      font-weight: bold;
      font-size: 14px;
    }
    
    .footer {
      text-align: center;
      margin-top: 10px;
      padding-top: 5px;
      border-top: 1px solid #000;
      font-size: 10px;
    }
    
    .number {
      direction: ltr;
      display: inline-block;
    }
    
    .payment-info {
      text-align: center;
      margin: 5px 0;
      font-size: 11px;
    }
    
    .barcode {
      text-align: center;
      margin: 5px 0;
      font-family: 'Libre Barcode 128', monospace;
      font-size: 24px;
    }
    
    @media print {
      body {
        width: 80mm;
        margin: 0;
        padding: 2mm;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="business-name">${settings.businessName}</div>
    <div style="font-size: 10px;">POS System</div>
  </div>
  
  <div class="order-info">
    <div><strong>${t('orderNumber')}: ${order.orderNumber}</strong></div>
    <div class="number">${new Date(order.createdAt).toLocaleString(settings.language === 'ar' ? 'ar-SA' : 'en-US')}</div>
    <div>${t('cashier')}: ${order.cashierName}</div>
    <div>${t('status')}: ${t(order.status)}</div>
  </div>
  
  <div class="items-header">
    ${isRTL ? 'المجموع    الكمية × السعر    الصنف' : 'ITEM           QTY×PRICE    TOTAL'}
  </div>
  
  <div class="items">
    ${order.items.map((item: any) => `
      <div class="item">
        <div class="item-name">${item.productName}</div>
        <div class="item-details">
          <span class="number">${item.quantity} × ${formatPrice(item.basePrice)}</span>
          <span class="number">${formatPrice(item.total)}</span>
        </div>
      </div>
    `).join('')}
  </div>
  
  <div class="totals">
    <div class="total-line grand-total">
      <span>${t('total')}:</span>
      <span class="number">${formatPrice(order.total)}</span>
    </div>
  </div>
  
  <div class="payment-info">
    <div><strong>${t('payment')}: ${order.paymentMethod?.toUpperCase() || 'CASH'}</strong></div>
  </div>
  
  <div class="barcode">
    *${order.orderNumber}*
  </div>
  
  <div class="footer">
    <div>${settings.receiptFooter || t('thankYou')}</div>
    <div style="margin-top: 5px; font-size: 9px;">
      ${isRTL ? 'شكراً لزيارتكم - نتطلع لخدمتكم مرة أخرى' : 'Thank you - Come again!'}
    </div>
  </div>
</body>
</html>`;
}

export function printReceipt(content: string) {
  const printWindow = window.open('', '_blank', 'width=300,height=600');
  if (printWindow) {
    printWindow.document.write(content);
    printWindow.document.close();
    
    // Wait for content to load then print
    printWindow.onload = () => {
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 250);
    };
  }
}